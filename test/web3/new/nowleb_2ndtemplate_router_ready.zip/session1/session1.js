// JavaScript for session1
