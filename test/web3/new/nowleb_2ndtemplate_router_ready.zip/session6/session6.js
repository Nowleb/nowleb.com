// JS for session6
