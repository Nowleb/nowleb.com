// JS for session2
