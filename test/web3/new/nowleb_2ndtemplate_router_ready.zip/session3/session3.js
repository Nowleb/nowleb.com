// JS for session3
