// JS for ribbon
