
document.addEventListener("DOMContentLoaded", () => {
  const adContainer = document.getElementById("top-ad");
  fetch("ads/top/ads.json")
    .then(response => response.json())
    .then(data => {
      const ads = data.ads;
      if (ads.length === 0) return;

      let index = 0;
      const showAd = () => {
        const ad = ads[index];
        adContainer.innerHTML = `
          <div class="ad-slot-header__wrapper">
            <div class="top-ad-label">Advertisement</div>
            <a href="\${ad.link}" target="_blank">
              <img src="\${ad.image}" alt="\${ad.title}" class="ad-img" />
            </a>
          </div>
        `;
        index = (index + 1) % ads.length;
      };

      showAd();
      setInterval(showAd, 10000); // Rotate every 10 seconds
    })
    .catch(err => console.error("Failed to load ads:", err));
});
