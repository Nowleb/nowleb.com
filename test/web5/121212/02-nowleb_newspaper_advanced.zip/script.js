document.addEventListener("DOMContentLoaded", () => {
  const ticker = document.getElementById("live-ticker");
  const headlines = [
    "Breaking: Global leaders sign historic pact",
    "Economy rebounds with record job growth",
    "New technology reshapes future of education",
    "Health officials approve new treatment protocol"
  ];
  let i = 0;
  setInterval(() => {
    ticker.textContent = headlines[i % headlines.length];
    i++;
  }, 3000);
});
