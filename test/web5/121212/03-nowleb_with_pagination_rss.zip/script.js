
let articles = [];
let currentPage = 1;
const perPage = 3;

fetch('articles.json')
  .then(res => res.json())
  .then(data => {
    articles = data;
    renderArticles();
  });

function renderArticles() {
  const grid = document.getElementById("article-grid");
  grid.innerHTML = "";
  let start = (currentPage - 1) * perPage;
  let end = start + perPage;
  let pageArticles = articles.slice(start, end);
  pageArticles.forEach(a => {
    grid.innerHTML += `<div class="news-card">
      <img src="images/${a.image}" alt="${a.title}">
      <h4>${a.title}</h4>
      <p>${a.summary}</p>
      <a href="article${a.id}.html">Read more</a>
    </div>`;
  });
  document.getElementById("page-number").textContent = currentPage;
}

function changePage(delta) {
  const totalPages = Math.ceil(articles.length / perPage);
  currentPage += delta;
  if (currentPage < 1) currentPage = 1;
  if (currentPage > totalPages) currentPage = totalPages;
  renderArticles();
}

// RSS Feed Integration
fetch("https://api.rss2json.com/v1/api.json?rss_url=https://feeds.bbci.co.uk/news/rss.xml")
  .then(response => response.json())
  .then(data => {
    const feed = data.items.map(item => item.title).slice(0, 5).join(" • ");
    document.getElementById("rss-feed").textContent = feed;
  });
