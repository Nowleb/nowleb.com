
document.addEventListener("DOMContentLoaded", () => {
  const links = ['pavlos', 'Brooklyn Bridge incident', 'Russia-Ukraine talks', 'Romania’s presidential election re-run', 'Eurovision Song Contest', 'Poland election', 'Celebrity tequila', 'Labubus'];

  const container = document.getElementById("ribbon-links");
  links.forEach((text) => {
    const span = document.createElement("span");
    const a = document.createElement("a");
    a.href = "#";
    a.textContent = text;
    span.appendChild(a);
    container.appendChild(span);
  });
});
