
document.addEventListener("DOMContentLoaded", () => {
  const loadHTML = (id, file) => {
    fetch(file)
      .then(res => res.text())
      .then(data => {
        document.getElementById(id).innerHTML = data;
      });
  };

  // Load top ad
  loadHTML("top-ad", "ads/top_ads/top_ads.html");

  // Load header and footer
  loadHTML("header", "header.html");
  loadHTML("footer", "footer.html");

  // Load headline ribbon
  loadHTML("headline-ribbon", "headline_ribbon.html");

  // Load sessions
  for (let i = 1; i <= 9; i++) {
    loadHTML("session-" + i, `session${i}.html`);
  }

  // Auto-refresh ribbon and session-1 every 60 seconds
  setInterval(() => {
    loadHTML("headline-ribbon", "headline_ribbon.html");
    loadHTML("session-1", "session1.html");
  }, 60000);
});

// Toggle mobile menu
function toggleMenu() {
  const nav = document.getElementById("main-nav");
  nav.classList.toggle("active");
}

// Load section content dynamically into any target element
function loadContent(file, targetId) {
  fetch(file)
    .then(res => res.text())
    .then(data => {
      document.getElementById(targetId).innerHTML = data;
    });
}
