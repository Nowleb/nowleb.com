
// JavaScript for session1

function imageLoadError(img) {
  img.onerror = null;
  img.src = 'images/session1/default.jpg'; // fallback image
}
